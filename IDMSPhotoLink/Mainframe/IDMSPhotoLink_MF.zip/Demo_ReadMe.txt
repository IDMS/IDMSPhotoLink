Unzip the "EBCDIC" files and upload them to the mainframe.  These files are
in EBCDIC formate, so be sure to use a binary or image format.

Use IEBCOPY or similar utility to expand these sequential files into source
and JCL libraries.  If you are using VSE or need to otherwise expand the files
manually, the beginning of each member contains control statement beginning
with ./ ADD NAME=membername

Once the libraries are created, follow the instructions in memmber EMP$TEPS
of the source library.
